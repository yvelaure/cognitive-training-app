# GitHub Actions Workflow - Copy and Paste

## **Workflow Content to Copy:**

```yaml
name: Build Android APK

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v4
    
    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: '20'
        cache: 'npm'
        
    - name: Setup Java
      uses: actions/setup-java@v4
      with:
        distribution: 'temurin'
        java-version: '17'
        
    - name: Install dependencies
      run: npm ci
      
    - name: Build web app
      run: npm run build
      
    - name: Sync Capacitor
      run: npx cap sync android
      
    - name: Make gradlew executable
      run: chmod +x android/gradlew
      
    - name: Build APK
      run: cd android && ./gradlew assembleRelease
      
    - name: Upload APK
      uses: actions/upload-artifact@v4
      with:
        name: brain-games-hub-apk
        path: android/app/build/outputs/apk/release/app-release.apk
```

## **How to Use This:**

### **Method 1: Manual Upload to GitHub**
1. **Go** to GitHub.com → your repository
2. **Click** "Add file" → "Create new file"
3. **Type** filename: `.github/workflows/build-android.yml`
4. **Copy** the entire workflow content above
5. **Paste** it into the file editor
6. **Click** "Commit new file"

### **Method 2: If GitHub Desktop Shows the File**
1. **Open** GitHub Desktop
2. **Look** for `.github/workflows/build-android.yml` in changes
3. **Add** commit message: "Add Android APK build workflow"
4. **Click** "Commit to main"
5. **Click** "Push origin"

## **After Adding the Workflow:**
1. **Wait** 1-2 minutes
2. **Refresh** GitHub.com
3. **Go** to Actions tab
4. **You should see** "Build Android APK" workflow
5. **Click** "Run workflow" to start the build

The workflow will build your professional Android APK with all 13+ games, native features, and payment integration ready for Google Play Store submission.