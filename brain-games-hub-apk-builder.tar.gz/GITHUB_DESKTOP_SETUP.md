# GitHub Desktop Setup Guide

## Step 1: Download GitHub Desktop
1. Go to https://desktop.github.com/
2. Click "Download for Windows" (or Mac/Linux)
3. Install the application
4. Open GitHub Desktop

## Step 2: Sign In
1. Click "Sign in to GitHub.com"
2. Enter your GitHub username and password
3. Authorize GitHub Desktop

## Step 3: Create Repository
1. Click "Create a New Repository on your hard drive"
2. Name: `brain-games-hub`
3. Description: "Brain training platform with 13+ puzzle games"
4. Choose location on your computer
5. Initialize with README: ✓ (checked)
6. Git ignore: Node (select from dropdown)
7. License: MIT License
8. Click "Create Repository"

## Step 4: Add Your Project Files
1. **Extract** your braingames-voltbuilder.tar.gz file
2. **Open** the local repository folder (GitHub Desktop shows the path)
3. **Copy all files** from extracted folder into this repository folder:
   - android/
   - client/
   - server/
   - certificates/
   - package.json
   - capacitor.config.ts
   - All other files
4. **Important**: Also copy the `.github/` folder (contains build workflow)

## Step 5: Commit and Push
1. GitHub Desktop will show all your new files
2. Add commit message: "Initial Brain Games Hub project"
3. Click "Commit to main"
4. Click "Publish repository"
5. Make sure "Keep this code private" is UNCHECKED (needs to be public for free GitHub Actions)
6. Click "Publish Repository"

## Step 6: Build APK
1. Go to your repository on GitHub.com
2. Click "Actions" tab
3. Click "Build Android APK"
4. Click "Run workflow"
5. Wait 5-10 minutes
6. Download APK from "Artifacts"

## Expected Result
Your Brain Games Hub will be automatically built into a professional Android APK ready for Google Play Store submission.

## Why GitHub Desktop is Better
- Visual interface (no command line)
- Automatic file detection
- Easy commit and push process
- Works with large projects
- Built-in conflict resolution