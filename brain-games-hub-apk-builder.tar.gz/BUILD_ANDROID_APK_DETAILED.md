# Build Android APK - Complete Guide

## 🎯 **Build Your Brain Games Hub APK**

### **Method 1: Using Android Studio (Recommended)**

#### **Step 1: Download Android Studio**
1. Go to: https://developer.android.com/studio
2. Download Android Studio for your operating system
3. Install following the setup wizard
4. Install Android SDK when prompted

#### **Step 2: Open Your Project**
1. Launch Android Studio
2. Choose "Open an existing Android Studio project"
3. Navigate to your project folder
4. Select the `android/` folder
5. Click "Open"

#### **Step 3: Wait for Project Sync**
- Android Studio will sync your project
- Download necessary dependencies
- This may take 5-10 minutes first time
- Wait for "Gradle sync finished" message

#### **Step 4: Generate Signed APK**
1. Go to: **Build** → **Generate Signed Bundle/APK**
2. Select: **APK** (not Android App Bundle for now)
3. Click: **Next**

#### **Step 5: Create Keystore (First Time)**
1. Click: **Create new...**
2. Choose keystore path: `braingames-keystore.jks`
3. Set keystore password: (save this password!)
4. Key alias: `braingames`
5. Key password: (can be same as keystore password)
6. Fill certificate information:
   - First and Last Name: Your name
   - Organization: Brain Games Hub
   - Organization Unit: Development
   - City: Your city
   - State: Your state
   - Country: Your country code (US, UK, etc.)
7. Click: **OK**

#### **Step 6: Complete APK Generation**
1. Select build variant: **release**
2. Check: **V1 (Jar Signature)** and **V2 (Full APK Signature)**
3. Click: **Finish**

#### **Step 7: Find Your APK**
- APK location: `android/app/build/outputs/apk/release/`
- File name: `app-release.apk`
- This is your Google Play Store ready APK

### **Method 2: Command Line (Alternative)**

#### **Prerequisites**
- Java JDK installed
- Android SDK installed
- Environment variables set

#### **Build Commands**
```bash
# Navigate to android folder
cd android

# Build release APK
./gradlew assembleRelease

# Find APK in: android/app/build/outputs/apk/release/
```

### **Method 3: Using Capacitor**

#### **Sync and Build**
```bash
# Sync your web app to android
npx cap sync android

# Copy latest changes
npx cap copy android

# Open in Android Studio
npx cap open android
```

## 🔧 **APK Verification**

### **Check Your APK**
1. **Size**: Should be 10-50MB for your app
2. **Name**: `app-release.apk`
3. **Location**: `android/app/build/outputs/apk/release/`
4. **Signed**: Must be signed with your keystore

### **Test Your APK**
1. **Install on test device**: `adb install app-release.apk`
2. **Test all 13+ games**: Ensure they work properly
3. **Test payments**: Verify Stripe integration
4. **Test offline mode**: Disconnect internet and test
5. **Test notifications**: Check push notifications work

## 📋 **APK Details for Google Play**

### **Your App Information**
- **Package Name**: com.braingames.hub
- **Version Code**: 1
- **Version Name**: 1.0.0
- **Minimum SDK**: 22 (Android 5.1)
- **Target SDK**: 34 (Android 14)
- **Permissions**: Camera, storage, internet, notifications

### **Features Included**
- 13+ brain training games
- Real-time IQ scoring
- Achievement system
- Global leaderboards
- Stripe payment integration
- Haptic feedback
- Push notifications
- Offline functionality

## 🚀 **Upload to Google Play Console**

### **When You Have APK Ready**
1. **Log into Google Play Console**
2. **Create new app**: "Brain Games Hub"
3. **Upload APK**: In "App releases" section
4. **Fill store listing**: Use descriptions I provided
5. **Upload screenshots**: 8 screenshots showing features
6. **Set pricing**: Free with in-app purchases
7. **Submit for review**: 1-3 days approval

### **APK Requirements Met**
- ✅ Signed with release keystore
- ✅ Proper package name
- ✅ Version information correct
- ✅ All permissions declared
- ✅ No debug information
- ✅ Optimized for release

## 🔐 **Important: Save Your Keystore**

### **Critical Files to Backup**
- `braingames-keystore.jks` (your keystore file)
- Keystore password
- Key alias and password
- Certificate information

### **Why This Matters**
- **Required for all future updates**
- **Cannot be recreated if lost**
- **Google Play requires same signature**
- **Backup to secure location**

## 💡 **Troubleshooting**

### **Common Issues**

#### **Build Errors**
- Clean project: Build → Clean Project
- Invalidate caches: File → Invalidate Caches and Restart
- Check internet connection
- Update Android Studio

#### **Signing Issues**
- Verify keystore path is correct
- Check passwords are correct
- Ensure key alias matches
- Regenerate if necessary

#### **App Not Installing**
- Check device has enough storage
- Enable "Unknown sources" in settings
- Try different device
- Check APK isn't corrupted

### **Performance Optimization**
- Your APK is already optimized
- ProGuard enabled for release builds
- Resources compressed
- Code obfuscated for security

## 🎯 **Ready for Google Play Store**

Your Brain Games Hub APK will be ready for Google Play Store submission with:
- Professional native Android app
- All 13+ games fully functional
- Stripe payment integration working
- Native features (haptic feedback, notifications)
- Proper versioning and signing
- Optimized for performance and battery life

Once you have your signed APK, you can upload it to Google Play Console and submit for review!