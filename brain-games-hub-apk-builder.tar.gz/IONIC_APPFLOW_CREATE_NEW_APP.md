# Ionic AppFlow - Create New App Process

## **Creating New App in Ionic AppFlow**

### **Step 1: Click "Create New App"**
1. **Find** the "Create New App" or "New App" button
2. **Click** to start the app creation process

### **Step 2: Choose Repository Connection**
1. **Select** "Connect a Git Repository"
2. **Choose** "GitHub" as your source
3. **Select** your `cognitive-training-app` repository
4. **Click** "Continue" or "Connect"

### **Step 3: Configure Your App**
Fill in these exact settings:

**Basic Information:**
- **App Name**: `Brain Games Hub`
- **App ID**: `com.braingameshub.app`

**Technical Settings:**
- **Framework**: `Capacitor` (very important!)
- **Build Tool**: `Capacitor`
- **Platform**: `Android`
- **Branch**: `main` (or `master`)

**Optional Settings:**
- **Description**: `Cognitive training app with 13+ brain games`
- **Version**: `1.0.0`

### **Step 4: Create the App**
1. **Review** all settings
2. **Click** "Create App" or "Continue"
3. **Wait** for app to be created

### **Step 5: Start Android Build**
After app creation:
1. **Navigate** to "Builds" tab
2. **Click** "Start Build" or "New Build"
3. **Select** "Android" platform
4. **Choose** "APK" as target
5. **Select** "Release" build type
6. **Click** "Start Build"

### **Step 6: Monitor Build Progress**
- **Build Status**: Shows progress
- **Build Time**: 10-15 minutes
- **Build Logs**: Available for debugging
- **Completion**: Download button appears

### **What You'll Get:**
- Professional Android APK (~15-25 MB)
- All 13+ brain training games integrated
- Native Android features (haptic feedback, notifications)
- Google Play Store ready signing
- Kotlin performance optimization

**Start by clicking "Create New App" and use the settings above!**