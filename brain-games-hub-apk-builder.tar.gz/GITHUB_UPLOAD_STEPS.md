# GitHub Upload Steps - Exact Order

## **Step 1: Upload Root Files First**
1. **Upload** `package.json` (the main project file)
2. **Upload** `capacitor.config.ts` (mobile app configuration)

## **Step 2: Create Client Folder & Upload Client Files**
1. **Create** folder named `client`
2. **Upload** to client folder:
   - `index.html`
   - `manifest.json` (from client/public/)
   - `icon-192x192.png` (from client/public/)
   - `icon-512x512.png` (from client/public/)
   - `sw.js` (from client/public/)

## **Step 3: Create Client/src Folder & Upload Source Files**
1. **Create** folder `client/src`
2. **Upload** to client/src:
   - `App.tsx`
   - `main.tsx`
   - `index.css`

## **Step 4: Create Client/src/components Folder**
1. **Create** folder `client/src/components`
2. **Upload** ALL files from the components folder

## **Step 5: Create Client/src/pages Folder**
1. **Create** folder `client/src/pages`
2. **Upload** ALL files from the pages folder

## **Step 6: Create Server Folder**
1. **Create** folder `server`
2. **Upload** ALL files from the server folder

## **Step 7: Create Android Folder**
1. **Create** folder `android`
2. **Upload** ALL files from the android folder

## **Most Important Files to Upload:**
- `package.json` ✓
- `capacitor.config.ts` ✓
- `client/src/App.tsx` ✓
- `client/src/main.tsx` ✓
- `client/src/index.css` ✓
- All files in `client/src/components/` ✓
- All files in `client/src/pages/` ✓
- All files in `server/` ✓
- All files in `android/` ✓

Start with the root files first, then create folders and upload the contents. This will give VoltBuilder everything it needs to build your APK!