# Android Studio Troubleshooting - Fix Common Issues

## **Common First-Time Mistakes and Solutions:**

### **Mistake 1: Clicked "Start a new project"**
**Solution:**
1. **Close** the new project window
2. **File** → **Close Project**
3. **You'll see** the welcome screen again
4. **Click** "Open an existing Android Studio project"

### **Mistake 2: Opened wrong folder**
**Solution:**
1. **File** → **Close Project**
2. **Click** "Open an existing Android Studio project"
3. **Navigate** to your Brain Games Hub folder
4. **Select** the `android/` folder specifically (not root folder)

### **Mistake 3: Can't find downloaded project**
**Solution:**
1. **Go back** to Replit
2. **Download** your project again as ZIP
3. **Extract** to Desktop
4. **Look for** the `android/` folder inside

### **Mistake 4: Gradle sync failed**
**Solution:**
1. **Wait** for sync to complete (can take 10+ minutes)
2. **Click** "Sync Project with Gradle Files" if needed
3. **Accept** any license agreements that appear

### **Mistake 5: SDK not found**
**Solution:**
1. **File** → **Settings** → **Appearance & Behavior** → **System Settings** → **Android SDK**
2. **Install** latest Android SDK
3. **Accept** all licenses

## **How to Start Over:**
1. **Close** Android Studio completely
2. **Reopen** Android Studio
3. **Click** "Open an existing Android Studio project"
4. **Navigate** to your extracted Brain Games Hub folder
5. **Select** the `android/` folder
6. **Click** "OK"
7. **Wait** for Gradle sync

## **What Should Happen:**
1. **Project opens** with folder structure visible
2. **Gradle sync** starts automatically
3. **No red errors** in bottom panel
4. **Green checkmark** appears when ready
5. **Build menu** becomes available

## **Next Step After Fix:**
1. **Build** → **Generate Signed Bundle/APK**
2. **Create** keystore for signing
3. **Build** your professional APK

**Tell me what exactly went wrong and I'll help you fix it!**