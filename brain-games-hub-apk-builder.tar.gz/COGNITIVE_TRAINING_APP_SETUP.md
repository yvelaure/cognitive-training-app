# Cognitive Training App - GitHub Setup

## **Step 1: Create New Repository**
1. **Go** to github.com
2. **Click** "New repository"
3. **Name** it: `cognitive-training-app`
4. **Set** to Public
5. **Add** description: "Advanced brain training platform with 13+ cognitive games, adaptive difficulty, and offline functionality"
6. **Click** "Create repository"

## **Step 2: Upload Root Files**
1. **Click** "Create new file"
2. **Type** `package.json`
3. **Copy** content from Replit's `package.json`
4. **Commit** file

5. **Click** "Create new file"
6. **Type** `capacitor.config.ts`
7. **Copy** content from Replit's `capacitor.config.ts`
8. **Commit** file

## **Step 3: Upload Client Files**
1. **Click** "Create new file"
2. **Type** `client/index.html`
3. **Copy** HTML content from previous steps
4. **Commit** file

5. **Click** "Create new file"
6. **Type** `client/src/main.tsx`
7. **Copy** React entry point content
8. **Commit** file

9. **Click** "Create new file"
10. **Type** `client/src/index.css`
11. **Copy** CSS content from previous steps
12. **Commit** file

## **Step 4: After Upload**
1. **Go** to voltbuilder.com
2. **Sign in** with your personal GitHub account
3. **Select** "GitHub Repository"
4. **Choose** `cognitive-training-app`
5. **Build** Android APK

The name `cognitive-training-app` is professional and clearly shows it's a brain training application with cognitive games.

Ready to create the `cognitive-training-app` repository?