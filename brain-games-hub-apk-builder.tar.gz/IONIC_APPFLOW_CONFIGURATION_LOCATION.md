# Where to Find App Configuration in Ionic AppFlow

## **After Connecting GitHub Repository:**

### **Step 1: Look for Configuration Form**
After selecting your repository, you should see a form with these fields:
- **App Name** field
- **App ID** field  
- **Framework** dropdown
- **Platform** selection

### **Step 2: If You Don't See Configuration Form**
1. **Look** for "App Settings" or "Configuration" tab
2. **Click** "New App" or "Create App" button
3. **Check** the main dashboard for setup options
4. **Look** for "Get Started" or "Setup" links

### **Step 3: Common Locations**
- **Main Dashboard**: "Create New App" button
- **Left Sidebar**: "Apps" → "New App"
- **Repository Page**: "Configure App" or "Setup" button
- **Getting Started**: Follow the setup wizard

### **Step 4: Configuration Fields to Fill**
When you find the form:
- **App Name**: `Brain Games Hub`
- **App ID**: `com.braingameshub.app`
- **Framework**: `Capacitor`
- **Platform**: `Android`
- **Branch**: `main`

### **Step 5: After Configuration**
1. **Click** "Create App" or "Save"
2. **Navigate** to "Builds" tab
3. **Click** "Start Build"
4. **Select** Android APK
5. **Wait** for build completion

### **If You're Still Stuck:**
- **Look** for any "Setup" or "Configure" buttons
- **Check** the top navigation menu
- **Try** clicking on your repository name
- **Look** for a "Continue" or "Next" button

**The configuration form should appear right after connecting your GitHub repository!**