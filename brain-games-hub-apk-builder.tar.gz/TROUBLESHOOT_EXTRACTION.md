# Troubleshooting File Extraction

## Common Issues with .tar.gz Files

### Issue 1: Files Not Extracting Properly
**Problem**: braingames-voltbuilder.tar.gz doesn't extract normally
**Solutions**:
1. **Try 7-Zip** (free): Download from https://www.7-zip.org/
2. **Try WinRAR** (free trial): Download from https://www.win-rar.com/
3. **Use online extractor**: https://extract.me/

### Issue 2: Files Extract to Wrong Location
**Problem**: Files extract but you can't find them
**Solutions**:
1. **Check Downloads folder** - usually extracts there
2. **Look for folder named** "braingames-voltbuilder"
3. **Search PC** for "android" or "client" folders

### Issue 3: Extraction Creates Nested Folders
**Problem**: Multiple nested folders instead of direct content
**Solutions**:
1. **Look inside** the extracted folder for another folder
2. **Copy contents** from the inner folder, not the outer one
3. **You want the folders**: android/, client/, server/, certificates/

### Issue 4: Windows Extraction Problems
**Problem**: Windows built-in extractor fails
**Solutions**:
1. **Right-click** .tar.gz file
2. **Select "Extract All"**
3. **If fails**, use 7-Zip or WinRAR instead

## What You Should See After Extraction:
- **android/** folder (mobile app config)
- **client/** folder (React frontend)
- **server/** folder (backend API)
- **certificates/** folder (app signing)
- **package.json** file
- **capacitor.config.ts** file
- **Many other files**

## Next Steps Once Extracted:
1. **Copy ALL these files** to your GitHub repository folder
2. **GitHub Desktop** will detect them automatically
3. **Commit and publish** to GitHub
4. **Build APK** automatically

Try using 7-Zip if Windows extraction isn't working properly.