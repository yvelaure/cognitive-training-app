# Android Studio Download - Step by Step

## **Step 1: Go to Official Website**
1. **Open** your web browser
2. **Type** developer.android.com/studio
3. **Press** Enter

## **Step 2: Download Android Studio**
1. **Click** the big green "Download Android Studio" button
2. **Accept** the Terms and Conditions checkbox
3. **Click** "Download Android Studio for Windows" (or your OS)
4. **Wait** for download to complete (800MB-1GB file)

## **Step 3: Install Android Studio**
1. **Find** the downloaded file (usually in Downloads folder)
2. **Double-click** the installer file
3. **Click** "Next" through the installation wizard
4. **Choose** "Standard" installation type
5. **Accept** all default settings
6. **Click** "Install"
7. **Wait** 10-15 minutes for installation

## **Step 4: First Launch Setup**
1. **Launch** Android Studio when installation completes
2. **Choose** "Do not import settings" (first time)
3. **Click** "OK"
4. **Accept** Android SDK License Agreements
5. **Click** "Next" through setup wizard
6. **Wait** for SDK components to download (10-15 minutes)

## **Step 5: Ready to Build**
1. **Android Studio** opens with welcome screen
2. **Click** "Open an existing Android Studio project"
3. **Navigate** to your Brain Games Hub project
4. **Select** the `android/` folder
5. **Click** "OK"

## **System Requirements:**
- **Windows**: Windows 10/11 (64-bit)
- **RAM**: 8GB minimum (16GB recommended)
- **Storage**: 4GB free space
- **Internet**: Required for initial setup

## **Download Links:**
- **Windows**: developer.android.com/studio
- **Mac**: Same link, auto-detects your OS
- **Linux**: Same link, auto-detects your OS

## **What Happens After Download:**
1. **Installation**: 10-15 minutes
2. **First Setup**: 10-15 minutes SDK download
3. **Project Open**: 5-10 minutes Gradle sync
4. **APK Build**: 5-10 minutes compilation
5. **Total Time**: About 45 minutes start to finish

## **Troubleshooting:**
- **Slow Download**: Use stable internet connection
- **Installation Fails**: Run as administrator
- **SDK Issues**: Accept all licenses during setup
- **Gradle Errors**: Wait for full sync to complete

Your Brain Games Hub project is ready to open in Android Studio once installation completes!

**Start by going to developer.android.com/studio now!**