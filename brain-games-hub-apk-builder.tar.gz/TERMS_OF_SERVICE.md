# Terms of Service - Brain Games Hub

**Effective Date**: January 16, 2025  
**Last Updated**: January 16, 2025

## 1. Acceptance of Terms

By downloading, installing, or using Brain Games Hub ("the App"), you agree to be bound by these Terms of Service ("Terms"). If you do not agree to these Terms, do not use the App.

## 2. Description of Service

Brain Games Hub is a cognitive training application featuring 13+ brain training games designed to improve memory, focus, and cognitive abilities. The App includes:

- Multiple brain training games
- Adaptive difficulty system
- Global leaderboards
- Avatar customization
- Progress tracking
- Social features
- Premium content and purchases

## 3. User Accounts and Registration

### Account Creation
- You may create an account using a username
- You are responsible for maintaining account security
- You must provide accurate information
- One account per person

### Account Responsibilities
- Keep your login credentials secure
- Notify us immediately of unauthorized access
- You are responsible for all activities under your account
- Do not share your account with others

## 4. Acceptable Use Policy

### Permitted Uses
- Play games for personal entertainment and cognitive training
- Participate in leaderboards and competitions
- Customize your avatar and profile
- Share achievements and progress

### Prohibited Uses
- Cheating, hacking, or exploiting game mechanics
- Harassment or inappropriate behavior toward other users
- Reverse engineering or attempting to access source code
- Using automated tools or bots
- Sharing inappropriate content
- Violating any applicable laws or regulations

## 5. In-App Purchases and Payments

### Purchase Terms
- All purchases are final and non-refundable except as required by law
- Prices are subject to change without notice
- Payment processing handled by third-party providers
- Purchases are tied to your account and platform

### Virtual Currency
- Coins are virtual currency with no real-world value
- Coins cannot be transferred between users
- Coins have no expiration date
- We reserve the right to modify coin values

### Payment Methods
We accept payments through:
- Apple App Store (iOS)
- Google Play Store (Android)
- Stripe (credit/debit cards)
- PayPal
- Razorpay
- Square

## 6. Intellectual Property Rights

### Our Rights
- Brain Games Hub and all content are owned by us
- Game designs, graphics, and code are protected by copyright
- Trademarks and logos are our property
- You may not reproduce, modify, or distribute our content

### Your Rights
- You retain rights to your username and avatar customization
- You may share gameplay screenshots and achievements
- You have a limited license to use the App for personal use

## 7. Privacy and Data Protection

### Data Collection
- We collect minimal personal information as outlined in our Privacy Policy
- Game progress and scores are stored to provide service
- Usage analytics help improve the App
- All data handling complies with privacy laws

### Data Security
- We implement industry-standard security measures
- Your data is encrypted during transmission
- We do not sell personal information to third parties
- You can request data deletion at any time

## 8. User-Generated Content

### Content Guidelines
- Keep usernames and profiles appropriate for all ages
- No offensive, discriminatory, or inappropriate content
- Respect other users and maintain positive interactions
- Follow community guidelines in social features

### Content Moderation
- We reserve the right to remove inappropriate content
- Violations may result in account suspension or termination
- We are not responsible for user-generated content
- Report inappropriate content through our support channels

## 9. Disclaimers and Limitations

### Service Availability
- The App is provided "as is" without warranties
- We do not guarantee uninterrupted service
- Features may be modified or discontinued
- Offline functionality available for core games

### Limitation of Liability
- We are not liable for indirect, incidental, or consequential damages
- Our liability is limited to the amount you paid for the App
- We are not responsible for third-party services or links
- Use the App at your own risk

## 10. Termination

### Your Rights
- You may stop using the App at any time
- You may delete your account and data
- Uninstalling the App terminates your use

### Our Rights
- We may terminate accounts for Terms violations
- We may suspend service for maintenance or updates
- We may discontinue the App with reasonable notice
- Termination does not entitle you to refunds

## 11. Updates and Modifications

### App Updates
- We may update the App to add features or fix issues
- Updates may be required for continued use
- New features may be subject to additional terms
- We will notify you of significant changes

### Terms Updates
- We may modify these Terms periodically
- Continued use after changes constitutes acceptance
- Significant changes will be communicated through the App
- You may terminate your account if you disagree with changes

## 12. Geographic Restrictions

### Availability
- The App is available worldwide through app stores
- Some features may not be available in all regions
- Payment methods vary by location
- Local laws and regulations apply

### Compliance
- You are responsible for compliance with local laws
- Some features may be restricted in certain jurisdictions
- We may modify service based on legal requirements

## 13. Contact Information

For questions about these Terms:

**Email**: legal@braingameshubapp.com  
**Business Email**: contact@braingameshubapp.com  
**Website**: braingameshubapp.com  
**Response Time**: Within 48 hours

## 14. Dispute Resolution

### Governing Law
- These Terms are governed by the laws of [Your Jurisdiction]
- Disputes will be resolved through binding arbitration
- Class action lawsuits are waived
- You may opt-out of arbitration within 30 days

### Resolution Process
1. Contact our support team first
2. 30-day informal resolution period
3. Binding arbitration if needed
4. Small claims court option available

## 15. Miscellaneous

### Entire Agreement
- These Terms constitute the complete agreement
- They supersede all prior agreements
- Privacy Policy is incorporated by reference

### Severability
- If any provision is invalid, the rest remains in effect
- Invalid provisions will be replaced with valid equivalents

### Assignment
- You may not transfer your rights under these Terms
- We may assign our rights and obligations

### Waiver
- Our failure to enforce any provision does not constitute a waiver
- Waivers must be in writing

## 16. Age Requirements

- Users must be 13 years or older
- Users under 18 need parental consent
- We do not knowingly collect data from children under 13
- Parents may request deletion of children's data

## 17. Technical Requirements

### System Requirements
- iOS 12.0 or later / Android 8.0 or later
- Internet connection for some features
- Sufficient storage space for installation
- Compatible device hardware

### Performance
- We strive for optimal performance across devices
- Older devices may experience limitations
- Regular updates improve performance and compatibility

---

**Brain Games Hub Development Team**  
**Last Updated**: January 16, 2025  
**Version**: 1.0

For support: contact@braingameshubapp.com