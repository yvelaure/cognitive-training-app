# Android Studio Setup - Build Your APK

## 🎯 **Download Android Studio**

### **Get Android Studio**
1. **Go to**: https://developer.android.com/studio
2. **Click**: "Download Android Studio"
3. **Choose**: Your operating system (Windows, Mac, Linux)
4. **Download**: ~1GB file
5. **Install**: Follow setup wizard

### **First Time Setup**
1. **Launch Android Studio**
2. **Complete setup wizard**
3. **Install Android SDK** (when prompted)
4. **Choose standard installation**
5. **Wait for components** to download (~2GB)

## 📂 **Open Your Project**

### **Import Your Brain Games Hub**
1. **Click**: "Open an existing Android Studio project"
2. **Navigate**: To your project folder
3. **Select**: The `android/` folder (important!)
4. **Click**: "Open"
5. **Wait**: For Gradle sync (5-10 minutes first time)

### **What You Should See**
- Project structure in left panel
- `app/` folder with your app code
- `build.gradle` files
- "Gradle sync finished" message

## 🔧 **Build Your APK**

### **Generate Signed APK**
1. **Go to**: Build → Generate Signed Bundle / APK
2. **Select**: APK (not Android App Bundle)
3. **Click**: Next

### **Create Keystore (First Time)**
1. **Click**: "Create new..."
2. **Keystore path**: Save as `braingames-keystore.jks`
3. **Password**: Create secure password (save this!)
4. **Key alias**: `braingames`
5. **Key password**: Same as keystore password
6. **Certificate info**:
   - First/Last Name: Your name
   - Organization: Brain Games Hub
   - City/State/Country: Your location
7. **Click**: OK

### **Complete Build**
1. **Select**: release
2. **Check**: V1 and V2 signatures
3. **Click**: Finish
4. **Wait**: 2-5 minutes for build

### **Find Your APK**
- **Location**: `android/app/build/outputs/apk/release/`
- **File**: `app-release.apk`
- **Size**: Should be 10-50MB

## 🎮 **Test Your APK**

### **Install on Device**
1. **Connect Android phone** via USB
2. **Enable Developer Options**:
   - Settings → About Phone
   - Tap "Build Number" 7 times
   - Go back to Settings → Developer Options
   - Enable "USB Debugging"
3. **Install APK**: `adb install app-release.apk`

### **Test Without Android Device**
1. **Use Android Emulator** in Android Studio
2. **Create virtual device**:
   - Tools → AVD Manager
   - Create Virtual Device
   - Choose Pixel 5 or similar
   - Download system image
   - Start emulator
3. **Install APK** on emulator

## 🏪 **Prepare for Google Play**

### **Your APK is Ready When**
- ✅ Builds without errors
- ✅ Signed with release keystore
- ✅ All 13+ games work
- ✅ Payments function properly
- ✅ No crashes or major bugs
- ✅ Proper app icon and metadata

### **APK Details**
- **Package name**: com.braingames.hub
- **Version**: 1.0.0
- **Min SDK**: Android 5.1+
- **Target SDK**: Android 14
- **Size**: Optimized for quick download

## 💡 **While Building**

### **Take Screenshots**
1. **Run your web app** in browser
2. **Use developer tools** to simulate mobile
3. **Capture 8 screenshots** following the guide
4. **Save as PNG** files for store listing

### **Prepare Store Assets**
1. **App icon**: 512x512 PNG
2. **Feature graphic**: 1024x500 PNG
3. **App description**: Use optimized version
4. **Screenshots**: 8 mobile screenshots

## 🚀 **Direct Google Play Access**

### **Android Studio Integration**
1. **After APK is built**
2. **Go to**: Build → Generate Signed Bundle
3. **Click**: "Google Play Console"
4. **This may provide direct access** to console
5. **Or guide you through** developer registration

### **Alternative Registration**
1. **Use built APK** as proof of serious development
2. **Contact Google Support** with business credentials
3. **Mention professional app** ready for submission
4. **Reference business email**: contact@braingameshubapp.com

## 🎯 **Success Timeline**

### **Today**
- Download and install Android Studio
- Open your android/ project
- Build your first APK

### **Tomorrow**
- Test APK thoroughly
- Take all 8 screenshots
- Prepare store assets

### **This Week**
- Access Google Play Console
- Upload APK and assets
- Submit for review

Your Brain Games Hub is ready to become a successful Android app. The APK build process will give you everything needed for Google Play Store submission.

Ready to download Android Studio and build your APK?