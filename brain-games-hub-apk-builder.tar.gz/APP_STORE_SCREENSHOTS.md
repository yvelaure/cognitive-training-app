# Brain Games Hub - Screenshot Guide

## Required Screenshots for Google Play Store

### 1. Main Menu/Hub Screen
**Description:** Show the main game selection screen with all 13+ games
**Key Elements:**
- Brain Games Hub logo
- Game thumbnails with "Play Now" buttons
- Clean, professional layout
- Coins/score display
- Settings and profile icons

### 2. IQ Challenge Gameplay
**Description:** Active IQ Challenge game showing sequence memory
**Key Elements:**
- Colored squares in sequence
- Current IQ score display
- Level indicator
- Clean gameplay interface
- Score progression

### 3. Memory Master Game
**Description:** Memory Master gameplay with pattern recognition
**Key Elements:**
- Pattern grid display
- Timer countdown
- Score tracking
- Visual feedback elements
- Game progress indicators

### 4. Global Leaderboard
**Description:** Leaderboard showing player rankings
**Key Elements:**
- Player rankings list
- Performance metrics
- Achievement badges
- Social competition elements
- Real-time updates

### 5. Achievement System
**Description:** Achievement/badge collection screen
**Key Elements:**
- Unlocked achievement badges
- Progress indicators
- Achievement descriptions
- Completion percentages
- Reward system

### 6. Avatar Customization
**Description:** Avatar customization interface
**Key Elements:**
- Avatar preview
- Customization options
- Item categories
- Coin-based purchases
- Rarity indicators

### 7. Daily Challenges
**Description:** Daily challenge interface
**Key Elements:**
- Challenge calendar
- Streak tracking
- Reward system
- Difficulty indicators
- Progress tracking

### 8. Analytics Dashboard
**Description:** Performance analytics and progress tracking
**Key Elements:**
- Performance graphs
- Cognitive scoring
- Progress over time
- Detailed statistics
- Performance insights

## Screenshot Specifications
- **Size:** 1080x1920 pixels (9:16 aspect ratio)
- **Format:** PNG or JPEG
- **Quality:** High resolution, clear text
- **Orientation:** Portrait mode
- **Count:** 8 screenshots minimum, 8 maximum

## Best Practices
- Use actual gameplay footage, not mockups
- Show diverse game content
- Highlight unique features
- Include UI elements clearly
- Ensure text is readable
- Show engaging gameplay moments
- Demonstrate key features visually
- Use consistent branding

Your Brain Games Hub screenshots should showcase the variety, engagement, and professional quality of your 13+ game collection.