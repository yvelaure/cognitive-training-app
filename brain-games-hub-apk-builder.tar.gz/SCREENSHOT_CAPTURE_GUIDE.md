# Screenshot Capture Guide - Brain Games Hub

## Required Screenshots for Google Play Store

You need **7 high-quality screenshots** showing your app's key features.

## Screenshot Requirements

### Technical Specifications
- **Resolution**: 1080x1920 pixels (portrait) or 1920x1080 (landscape)
- **Format**: PNG or JPEG
- **File size**: Maximum 8MB each
- **Aspect ratio**: 16:9 or 9:16
- **Content**: Real app screenshots (no mockups)

### Screenshot List

### 1. **Main Game Hub** (Most Important)
- **What to show**: All 13 games displayed in grid
- **Focus**: Clean, organized layout
- **Text overlay**: "13+ Brain Training Games"
- **Capture from**: Main app screen

### 2. **Enhanced IQ Challenge**
- **What to show**: Gameplay with sequence of colored squares
- **Focus**: Active game state with score
- **Text overlay**: "AI-Powered Adaptive Difficulty"
- **Capture from**: During actual gameplay

### 3. **Memory Master Game**
- **What to show**: Memory sequence challenge
- **Focus**: Glowing squares and score display
- **Text overlay**: "Test Your Memory Skills"
- **Capture from**: Mid-game action

### 4. **Math Wizard**
- **What to show**: Arithmetic problems being solved
- **Focus**: Problem display and answer options
- **Text overlay**: "Quick Math Challenges"
- **Capture from**: During problem solving

### 5. **Global Leaderboard**
- **What to show**: Player rankings and scores
- **Focus**: Competitive elements
- **Text overlay**: "Compete Globally"
- **Capture from**: Leaderboard screen

### 6. **Achievement System**
- **What to show**: Unlocked badges and progress
- **Focus**: Achievement gallery
- **Text overlay**: "Unlock Achievements"
- **Capture from**: Achievement screen

### 7. **Daily Challenge**
- **What to show**: Daily puzzle interface
- **Focus**: Special challenge features
- **Text overlay**: "New Challenge Every Day"
- **Capture from**: Daily challenge screen

## How to Capture Screenshots

### Method 1: Direct from App
1. Open your Brain Games Hub
2. Navigate to each screen
3. Take screenshot (Ctrl+Shift+S on Windows, Cmd+Shift+4 on Mac)
4. Save as PNG format

### Method 2: Mobile Device
1. Install app on Android device
2. Navigate to each screen
3. Take screenshot (Volume Down + Power button)
4. Transfer to computer

### Method 3: Android Studio Emulator
1. Run app in Android Studio emulator
2. Navigate to each screen
3. Click camera icon in emulator toolbar
4. Save screenshots

## Screenshot Enhancement Tips

### Add Text Overlays
- Use clean, readable fonts
- Highlight key features
- Keep text concise
- Use contrasting colors

### Optimize for App Store
- Show diverse gameplay
- Include UI elements
- Display score/progress
- Highlight unique features

### Tools for Enhancement
- **Canva**: Easy screenshot editing
- **Figma**: Professional design tool
- **GIMP**: Free image editor
- **Photoshop**: Advanced editing

## Screenshot Order Priority

1. **Main Hub**: Shows all games available
2. **Enhanced IQ**: Most advanced game
3. **Memory Master**: Popular brain training
4. **Leaderboard**: Social/competitive aspect
5. **Math Wizard**: Educational value
6. **Achievements**: Gamification features
7. **Daily Challenge**: Regular engagement

## Text Overlay Suggestions

### Screenshot 1: Main Hub
**"13+ Brain Training Games in One App"**

### Screenshot 2: Enhanced IQ
**"AI Adapts to Your Skill Level"**

### Screenshot 3: Memory Master
**"Boost Your Memory Power"**

### Screenshot 4: Math Wizard
**"Sharpen Your Math Skills"**

### Screenshot 5: Global Leaderboard
**"Compete with Players Worldwide"**

### Screenshot 6: Achievement System
**"Unlock Badges & Track Progress"**

### Screenshot 7: Daily Challenge
**"Fresh Challenges Every Day"**

## Common Mistakes to Avoid

- **Empty screens**: Always show active content
- **Poor quality**: Use high-resolution images
- **No context**: Include UI elements and scores
- **Cluttered text**: Keep overlays simple
- **Outdated content**: Use current app version
- **Generic screenshots**: Show unique features

## Final Checklist

- [ ] All 7 screenshots captured
- [ ] Correct resolution (1080x1920)
- [ ] PNG or JPEG format
- [ ] Text overlays added
- [ ] Features clearly visible
- [ ] No personal information shown
- [ ] Professional appearance
- [ ] Compressed for upload

Your screenshots should showcase the rich variety and professional quality of your Brain Games Hub!