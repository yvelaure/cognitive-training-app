# Android Studio Direct Download Links

## 🎯 **Direct Download Links**

### **For Windows**
**Direct Link**: https://redirector.gvt1.com/edgedl/android/studio/install/2024.1.1.12/android-studio-2024.1.1.12-windows.exe
**Size**: ~1.1GB
**Requirements**: Windows 10/11

### **For Mac**
**Direct Link**: https://redirector.gvt1.com/edgedl/android/studio/install/2024.1.1.12/android-studio-2024.1.1.12-mac.dmg
**Size**: ~1.2GB
**Requirements**: macOS 10.14+

### **For Linux**
**Direct Link**: https://redirector.gvt1.com/edgedl/android/studio/install/2024.1.1.12/android-studio-2024.1.1.12-linux.tar.gz
**Size**: ~1.1GB
**Requirements**: 64-bit Linux

### **Official Download Page**
**Main Site**: https://developer.android.com/studio
**Alternative**: https://developer.android.com/studio/index.html

## 📋 **Download Steps**

### **Step 1: Choose Your Platform**
1. **Windows**: Download the .exe file
2. **Mac**: Download the .dmg file  
3. **Linux**: Download the .tar.gz file

### **Step 2: Start Download**
1. **Click** the appropriate link above
2. **Save** to your Downloads folder
3. **Wait** for download to complete (~10-15 minutes)

### **Step 3: Installation**
1. **Windows**: Double-click .exe, run as administrator
2. **Mac**: Double-click .dmg, drag to Applications
3. **Linux**: Extract and run studio.sh

## 🚀 **After Installation**

### **First Launch**
1. **Open** Android Studio
2. **Choose**: "Do not import settings"
3. **Select**: "Standard" installation
4. **Install**: SDK components (~2GB download)
5. **Finish**: Setup wizard

### **Open Your Project**
1. **Select**: "Open an existing Android Studio project"
2. **Navigate**: To your project folder
3. **Choose**: The `android/` folder
4. **Click**: "Open"
5. **Wait**: For Gradle sync

### **Build Your APK**
1. **Menu**: Build → Generate Signed Bundle/APK
2. **Select**: APK
3. **Create**: New keystore
4. **Build**: Release APK
5. **Find**: APK in build/outputs/apk/release/

## 💡 **Quick Tips**

### **Download Tips**
- Use stable internet connection
- Download may take 10-15 minutes
- Choose correct platform version
- Keep installer file for future use

### **Installation Tips**
- Run as administrator (Windows)
- Allow through firewall
- Install to default location
- Accept all license agreements

### **Build Tips**
- First sync takes 5-10 minutes
- Keep keystore file safe
- Test APK before submission
- Build takes 2-5 minutes

Your Brain Games Hub APK will be ready for Google Play Store once Android Studio is installed and your project is built!