# VoltBuilder Upload Steps

## After Downloading braingames-voltbuilder.tar.gz

### Step 1: VoltBuilder Interface
1. **Go to** https://volt.build/
2. **Sign in** to your account
3. **Look for** "Upload your app" or "New Build" button
4. **Click** to start upload process

### Step 2: File Upload
1. **Select** braingames-voltbuilder.tar.gz from downloads
2. **Upload** file (3.6MB - takes 1-2 minutes)
3. **Wait** for project detection
4. **Verify** Capacitor project recognized

### Step 3: Build Configuration
Your project includes:
- **App Name**: Brain Games Hub
- **Package ID**: com.braingames.hub
- **Version**: 1.0.0
- **Platform**: Android
- **Build Type**: Release

### Step 4: Start Build
1. **Click** "Build APK" or "Start Build"
2. **Monitor** build progress
3. **Wait** 5-10 minutes for completion
4. **Download** signed APK when ready

### Step 5: Test APK
1. **Install** on Android device
2. **Test** all games function
3. **Verify** payment system works
4. **Check** native features

Your Brain Games Hub APK will be ready for Google Play Store submission!