# GitHub Desktop Commit Message Location

## Where to Find the Commit Message Box:

### Location:
**Bottom left corner** of the GitHub Desktop window

### What You'll See:
1. **Small text box** with placeholder text "Summary (required)"
2. **Larger text box** below it labeled "Description (optional)"
3. **Blue "Commit to main" button** below the text boxes

### Steps:
1. **Click** in the "Summary (required)" box
2. **Type**: "Add Android APK build workflow"
3. **Click** "Commit to main" button
4. **Click** "Push origin" button that appears

### Visual Indicators:
- **Left panel** shows your changed files
- **Right panel** shows file differences
- **Bottom section** has the commit message area

### If You Don't See It:
- **Scroll down** in the GitHub Desktop window
- **Look** at the very bottom left
- **Resize** the window if needed
- **Click** on a changed file to refresh the view

The commit message area is always at the bottom left of GitHub Desktop, below the file list.