# GitHub Desktop for PC - Download Guide

## Direct Download
**Windows Download**: https://desktop.github.com/

## System Requirements
- **Windows 10** or later (64-bit)
- **4 GB RAM** minimum
- **500 MB** free disk space
- **Internet connection** for initial setup

## Download Process
1. Click "Download for Windows"
2. File downloads: `GitHubDesktopSetup.exe`
3. Run the installer
4. Follow installation prompts
5. Launch GitHub Desktop

## Installation Steps
1. **Download** GitHubDesktopSetup.exe
2. **Run** as administrator if needed
3. **Install** to default location (recommended)
4. **Launch** GitHub Desktop
5. **Sign in** with your GitHub account

## Why GitHub Desktop for PC
- **Visual interface** - no command line needed
- **Drag and drop** file management
- **Automatic sync** with GitHub
- **Built-in conflict resolution**
- **Perfect for large projects** like Brain Games Hub

## Alternative for Older Windows
If you have older Windows (Windows 7/8):
- Use **GitHub CLI** instead
- Or use **GitHub web interface** with manual file upload

## Expected File Size
- **Download**: ~100 MB
- **Installed**: ~250 MB
- **Works with**: All Windows PCs from 2015+

After installation, you can easily upload your Brain Games Hub project files and trigger the automatic APK build process.