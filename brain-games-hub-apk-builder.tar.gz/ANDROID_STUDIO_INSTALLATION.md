# Android Studio Installation Guide

## 📥 **Download Android Studio**

### **Direct Download Links**
- **Windows**: https://developer.android.com/studio#downloads
- **Mac**: https://developer.android.com/studio#downloads
- **Linux**: https://developer.android.com/studio#downloads

### **File Details**
- **Size**: ~1GB installer
- **Name**: android-studio-[version]-[platform]
- **Format**: .exe (Windows), .dmg (Mac), .tar.gz (Linux)

## 🔧 **Installation Steps**

### **Windows Installation**
1. **Download**: android-studio-[version]-windows.exe
2. **Right-click**: On downloaded file
3. **Select**: "Run as administrator"
4. **Follow**: Installation wizard
5. **Choose**: Standard installation
6. **Install**: Android SDK (when prompted)
7. **Finish**: Setup process

### **Mac Installation**
1. **Download**: android-studio-[version]-mac.dmg
2. **Double-click**: DMG file
3. **Drag**: Android Studio to Applications folder
4. **Launch**: From Applications
5. **Follow**: Setup wizard
6. **Install**: SDK components

### **Linux Installation**
1. **Download**: android-studio-[version]-linux.tar.gz
2. **Extract**: To desired location
3. **Navigate**: To android-studio/bin/
4. **Run**: ./studio.sh
5. **Complete**: Setup wizard

## 🚀 **First Launch Setup**

### **Initial Configuration**
1. **Launch Android Studio**
2. **Import settings**: Choose "Do not import"
3. **Setup wizard**: Click "Next"
4. **Install type**: Select "Standard"
5. **UI theme**: Choose preferred theme
6. **SDK components**: Install recommended components
7. **Download**: SDK files (~2GB)
8. **Finish**: Setup process

### **What Gets Installed**
- **Android Studio IDE**
- **Android SDK**
- **Android Virtual Device (AVD)**
- **Build tools**
- **Platform tools**
- **System images**

## 📂 **Open Your Project**

### **Import Brain Games Hub**
1. **Click**: "Open an existing Android Studio project"
2. **Navigate**: To your project directory
3. **Select**: The `android/` folder (important!)
4. **Click**: "OK"
5. **Wait**: For Gradle sync (5-10 minutes)

### **Project Structure**
```
android/
├── app/
│   ├── src/
│   ├── build.gradle
│   └── ...
├── gradle/
├── build.gradle
└── settings.gradle
```

## 🔨 **Build Your APK**

### **Generate Signed APK**
1. **Menu**: Build → Generate Signed Bundle / APK
2. **Choose**: APK
3. **Click**: Next
4. **Create keystore**: First time only
5. **Build**: Release APK
6. **Wait**: 2-5 minutes

### **Keystore Creation**
1. **Click**: "Create new..."
2. **Save as**: braingames-keystore.jks
3. **Password**: Create secure password
4. **Key alias**: braingames
5. **Certificate**: Fill required fields
6. **Click**: OK

### **APK Location**
- **Path**: android/app/build/outputs/apk/release/
- **File**: app-release.apk
- **Size**: 10-50MB

## 📱 **Test Your APK**

### **Android Device Testing**
1. **Connect**: Android phone via USB
2. **Enable**: Developer options
3. **Enable**: USB debugging
4. **Install**: adb install app-release.apk
5. **Test**: All 13+ games

### **Emulator Testing**
1. **Tools**: AVD Manager
2. **Create**: Virtual device
3. **Start**: Emulator
4. **Install**: APK on emulator
5. **Test**: Functionality

## 🏪 **Ready for Google Play**

### **Your APK Contains**
- **13+ brain training games**
- **Real-time IQ scoring**
- **Achievement system**
- **Leaderboards**
- **Stripe payment integration**
- **Haptic feedback**
- **Push notifications**
- **Offline functionality**

### **Google Play Requirements Met**
- ✅ Properly signed APK
- ✅ Correct package name
- ✅ Version information
- ✅ All permissions declared
- ✅ Target SDK compliance
- ✅ No debug information

## 💡 **Installation Tips**

### **System Requirements**
- **RAM**: 8GB minimum, 16GB recommended
- **Disk**: 4GB for Android Studio + 2GB for SDK
- **OS**: Windows 10+, macOS 10.14+, Linux 64-bit

### **Troubleshooting**
- **Java**: Android Studio includes JDK
- **Permissions**: Run as administrator if needed
- **Antivirus**: May need to exclude Android Studio folder
- **Firewall**: Allow Android Studio internet access

### **Performance Tips**
- **Increase**: JVM heap size if needed
- **Close**: Unnecessary applications
- **Use**: SSD for better performance
- **Disable**: Unnecessary plugins

Your Brain Games Hub APK will be ready for Google Play Store submission once Android Studio is installed and your project is built!

Ready to download and install?