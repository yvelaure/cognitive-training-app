# Capacitor Build Configuration

## 🔧 **Build Configuration File**

### **capacitor.config.json**
```json
{
  "appId": "com.braingames.hub",
  "appName": "Brain Games Hub",
  "webDir": "client/dist",
  "server": {
    "androidScheme": "https"
  },
  "android": {
    "buildOptions": {
      "keystorePath": "braingames-keystore.jks",
      "keystoreAlias": "braingames",
      "releaseType": "AAB"
    }
  },
  "plugins": {
    "Haptics": {
      "enabled": true
    },
    "LocalNotifications": {
      "smallIcon": "ic_stat_icon_config_sample",
      "iconColor": "#488AFF",
      "sound": "beep.wav"
    },
    "SplashScreen": {
      "launchShowDuration": 3000,
      "launchAutoHide": true,
      "backgroundColor": "#ffffffff",
      "androidSplashResourceName": "splash",
      "androidScaleType": "CENTER_CROP",
      "showSpinner": false,
      "androidSpinnerStyle": "large",
      "spinnerColor": "#999999"
    }
  }
}
```

## 📱 **Build Commands**

### **Capacitor CLI Commands**
```bash
# Sync web app to native
npx cap sync android

# Copy latest changes
npx cap copy android

# Build APK
npx cap build android

# Open in Android Studio
npx cap open android
```

### **Gradle Build Commands**
```bash
# Debug build
./gradlew assembleDebug

# Release build
./gradlew assembleRelease

# Bundle (AAB) build
./gradlew bundleRelease
```

## 🎯 **Online Build Services**

### **Capacitor Live Updates**
1. **Ionic Appflow**: https://ionic.io/docs/appflow
2. **Capacitor Cloud**: Native cloud builds
3. **GitHub Actions**: Automated builds
4. **Netlify**: CI/CD integration

### **Build Configuration**
- **Build Type**: Release
- **Output**: APK or AAB
- **Signing**: Automatic keystore
- **Optimization**: ProGuard enabled

Your Brain Games Hub is configured for professional Android builds with all native features enabled.