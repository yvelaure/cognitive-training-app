# Ionic AppFlow - GitHub Template Selection

## **Creating App from GitHub Repository Template**

### **Step 1: Template Selection**
Since you see "Create Template New App":
1. **Look for** "Import from GitHub" or "Connect Repository" option
2. **Choose** "GitHub" as your source
3. **Select** "Import existing project" or "Use existing repository"

### **Step 2: Repository Selection**
1. **Find** your `cognitive-training-app` repository
2. **Select** the repository from the list
3. **Choose** `main` branch (or `master`)
4. **Click** "Continue" or "Import"

### **Step 3: App Configuration**
Fill in these settings:
- **App Name**: `Brain Games Hub`
- **App ID**: `com.braingameshub.app`
- **Framework**: `Capacitor` (critical!)
- **Template**: Skip templates, use "Existing Project"
- **Platform**: `Android`

### **Step 4: Framework Detection**
Ionic AppFlow should automatically detect:
- **React** frontend
- **Capacitor** configuration
- **Android** platform support
- **TypeScript** setup

### **Alternative Options to Look For:**
- "Import Existing Project"
- "Connect Git Repository"
- "Use GitHub Repository"
- "Custom Template"
- "Skip Template" (if available)

### **What NOT to Choose:**
- Don't select any Ionic starter templates
- Don't choose "Blank" or "Tabs" templates
- Skip any pre-built templates

### **Goal:**
Import your existing `cognitive-training-app` repository that contains all 13+ brain games, not create a new template project.

**Look for "Import from GitHub" or "Connect Repository" options in the template selection screen!**