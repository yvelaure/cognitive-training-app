# Android Studio First Launch - What to Click

## **Android Studio Welcome Screen Options:**

### **When Android Studio Opens, You'll See:**
1. **"Do not import settings"** - Click this (first time setup)
2. **"Import settings from..."** - Don't click this

### **Setup Wizard Steps:**
1. **Welcome Screen**: Click "Next"
2. **Install Type**: Choose "Standard" (recommended)
3. **UI Theme**: Choose "Darcula" or "IntelliJ" (your preference)
4. **SDK Components**: Click "Next" (accepts defaults)
5. **License Agreement**: Click "Accept" for all licenses
6. **Downloading Components**: Wait 10-15 minutes

### **After Setup Completes:**
You'll see the main Android Studio welcome screen with options:
- **"Start a new Android Studio project"** - Don't click this
- **"Open an existing Android Studio project"** - Click this one!
- **"Get from VCS"** - Don't click this
- **"Import project"** - Don't click this

## **What to Do Next:**
1. **Click** "Open an existing Android Studio project"
2. **Navigate** to your downloaded Brain Games Hub folder
3. **Select** the `android/` folder inside your project
4. **Click** "OK"
5. **Wait** for Gradle sync (5-10 minutes)

## **If You See License Errors:**
- **Accept** all Android SDK licenses
- **Wait** for components to download
- **Don't** skip the setup process

## **What NOT to Click:**
- ❌ "Start a new project" (creates empty project)
- ❌ "Import from VCS" (for Git repositories)
- ❌ "Import project" (for other formats)

**Click "Open an existing Android Studio project" when you see the welcome screen!**