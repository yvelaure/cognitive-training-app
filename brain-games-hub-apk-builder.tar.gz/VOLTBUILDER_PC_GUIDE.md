# VoltBuilder PC Guide - Build Your APK

## Step 1: Download Your Project Package
1. **Download** `braingames-voltbuilder.tar.gz` from your Replit project
2. **Save** to your PC desktop or downloads folder
3. **File size**: 3.5MB (quick download)

## Step 2: Visit VoltBuilder Website
1. **Open browser** on your PC
2. **Go to**: https://volt.build/
3. **Sign up** for free account
4. **Verify email** if required

## Step 3: Upload Your Project
1. **Click** "Upload Project" or "New Build"
2. **Select** `braingames-voltbuilder.tar.gz` from your PC
3. **Upload** (takes 1-2 minutes)
4. **Verify** project detected correctly

## Step 4: Configure Build Settings
Your project is pre-configured with:
- **App Name**: Brain Games Hub
- **Package ID**: com.braingames.hub
- **Version**: 1.0.0
- **Build Type**: Release
- **Platform**: Android

## Step 5: Start Build Process
1. **Click** "Build APK"
2. **Wait** 5-10 minutes for compilation
3. **Monitor** build progress in browser
4. **Download** APK when complete

## Step 6: Test Your APK
1. **Install** APK on Android device
2. **Test** all 13+ games work properly
3. **Verify** payment system functions
4. **Check** performance and features

## Expected Results
- **Build time**: 5-10 minutes
- **APK size**: ~20-30MB
- **Ready for**: Google Play Store upload
- **Cost**: Free (1 build per month)

Your Brain Games Hub APK will be professionally signed and ready for Google Play Store submission!