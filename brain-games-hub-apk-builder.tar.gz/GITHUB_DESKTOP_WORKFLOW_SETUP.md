# GitHub Desktop Workflow Setup

## Create the Build Workflow Using GitHub Desktop

### Step 1: Open Your Repository in GitHub Desktop
1. **Make sure** you're in your repository in GitHub Desktop
2. **Click** "Show in Explorer" to open the repository folder

### Step 2: Create the Workflow File
1. **In the repository folder**, create these folders: `.github/workflows/`
2. **Create** new file: `build-android.yml` inside the workflows folder
3. **Copy this content** into the file:

```yaml
name: Build Android APK

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v4
    
    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: '20'
        cache: 'npm'
        
    - name: Setup Java
      uses: actions/setup-java@v4
      with:
        distribution: 'temurin'
        java-version: '17'
        
    - name: Install dependencies
      run: npm ci
      
    - name: Build web app
      run: npm run build
      
    - name: Sync Capacitor
      run: npx cap sync android
      
    - name: Make gradlew executable
      run: chmod +x android/gradlew
      
    - name: Build APK
      run: cd android && ./gradlew assembleRelease
      
    - name: Upload APK
      uses: actions/upload-artifact@v4
      with:
        name: brain-games-hub-apk
        path: android/app/build/outputs/apk/release/app-release.apk
```

### Step 3: Commit Through GitHub Desktop
1. **Return to GitHub Desktop**
2. **You'll see** the new workflow file listed
3. **Commit message**: "Add Android APK build workflow"
4. **Click** "Commit to main"
5. **Click** "Push origin"

### Step 4: Check Actions on GitHub
1. **Go to** GitHub.com
2. **Open** your repository
3. **Click** Actions tab
4. **You'll see** "Build Android APK"
5. **Click** "Run workflow"

This method avoids the GitHub web interface reload issues completely.