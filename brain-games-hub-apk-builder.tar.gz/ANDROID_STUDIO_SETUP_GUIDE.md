# Android Studio Setup - Complete Guide

## **Step 1: Download Android Studio**
1. **Go** to developer.android.com/studio
2. **Click** "Download Android Studio"
3. **Accept** terms and conditions
4. **Download** will start automatically

## **Step 2: Install Android Studio**
1. **Run** the downloaded installer
2. **Choose** "Standard" installation
3. **Accept** all default settings
4. **Wait** for installation to complete (15-20 minutes)
5. **Launch** Android Studio when finished

## **Step 3: Initial Setup**
1. **Welcome screen** appears
2. **Click** "Next" through setup wizard
3. **Accept** Android SDK license agreements
4. **Download** required SDK components
5. **Wait** for setup to complete (10-15 minutes)

## **Step 4: Download Your Project**
1. **Go** to your Replit project
2. **Click** the download button or export
3. **Save** to your computer (e.g., Desktop)
4. **Extract** the files if in a zip

## **Step 5: Open Project in Android Studio**
1. **Android Studio** main screen
2. **Click** "Open an existing Android Studio project"
3. **Navigate** to your project folder
4. **Select** the `android/` folder inside your project
5. **Click** "OK"

## **Step 6: Wait for Project Setup**
1. **Gradle** sync will start automatically
2. **Wait** 5-10 minutes for sync to complete
3. **Green checkmark** appears when ready
4. **No red errors** should be visible

## **Step 7: Build Your APK**
1. **Build** menu → **Generate Signed Bundle/APK**
2. **Select** "APK" option
3. **Click** "Next"
4. **Create** new keystore (important for Google Play)
5. **Build** release APK
6. **Download** from output folder

Your professional APK will be ready for Google Play Store submission!

**Ready to start? Download Android Studio now!**