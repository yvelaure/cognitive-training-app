# Client Files for cognitive-training-app

## **Next Files to Upload:**

### **1. client/index.html**
1. **Click** "Create new file"
2. **Type** `client/index.html`
3. **Paste** this content:

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1" />
    <meta name="theme-color" content="#8b5cf6" />
    <link rel="manifest" href="/manifest.json" />
    <title>Cognitive Training App - Brain Games</title>
    <meta name="description" content="Advanced brain training platform with 13+ cognitive games, adaptive difficulty, and offline functionality" />
    
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="Cognitive Training">
    
    <script>
      if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
          navigator.serviceWorker.register('/sw.js')
            .then((registration) => {
              console.log('SW registered: ', registration);
            })
            .catch((registrationError) => {
              console.log('SW registration failed: ', registrationError);
            });
        });
      }
    </script>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

### **2. client/src/main.tsx**
1. **Click** "Create new file"
2. **Type** `client/src/main.tsx`
3. **Paste** this content:

```typescript
import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

createRoot(document.getElementById("root")!).render(<App />);
```

### **3. client/src/index.css**
1. **Click** "Create new file"
2. **Type** `client/src/index.css`
3. **Paste** this content:

```css
@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  * {
    @apply border-border;
  }

  body {
    @apply font-sans antialiased bg-background text-foreground;
    margin: 0;
    padding: 0;
    overflow-x: hidden;
    overflow-y: auto;
    width: 100vw;
    min-height: 100vh;
    -webkit-overflow-scrolling: touch;
    touch-action: manipulation;
  }
}

#root {
  width: 100%;
  min-height: 100vh;
  position: relative;
  -webkit-overflow-scrolling: touch;
  overflow-y: auto;
}

canvas {
  width: 100% !important;
  height: 100% !important;
  touch-action: none;
}

.animate-fade-in {
  animation: fadeIn 0.5s ease-in-out;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
```

Start with `client/index.html` first!