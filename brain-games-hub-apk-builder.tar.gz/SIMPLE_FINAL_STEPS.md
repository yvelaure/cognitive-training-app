# Fix GitHub Upload - Simple Steps

## **What Happened:**
You accidentally deleted the first file while creating the second one. This is normal - let's fix it.

## **Step 1: Recreate client/index.html**
1. **Click** "Create new file"
2. **Type** `client/index.html`
3. **Copy and paste** this content:

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1" />
    <meta name="theme-color" content="#8b5cf6" />
    <link rel="manifest" href="/manifest.json" />
    <title>Brain Games Hub - Offline Brain Training</title>
    <meta name="description" content="Complete offline brain training platform with 8+ cognitive games including IQ challenges, memory games, Sudoku, and more. Works offline!" />
    
    <!-- PWA Meta Tags -->
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="Brain Games">
    
    <!-- Service Worker Registration -->
    <script>
      if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
          navigator.serviceWorker.register('/sw.js')
            .then((registration) => {
              console.log('SW registered: ', registration);
            })
            .catch((registrationError) => {
              console.log('SW registration failed: ', registrationError);
            });
        });
      }
    </script>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

4. **Click** "Commit new file"

## **Step 2: Create client/src/main.tsx**
1. **Click** "Create new file"
2. **Type** `client/src/main.tsx`
3. **Copy and paste** this content:

```typescript
import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

createRoot(document.getElementById("root")!).render(<App />);
```

4. **Click** "Commit new file"

## **Step 3: Create client/src/index.css**
1. **Click** "Create new file"
2. **Type** `client/src/index.css`
3. **Copy and paste** this content:

```css
@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  * {
    @apply border-border;
  }

  body {
    @apply font-sans antialiased bg-background text-foreground;
    margin: 0;
    padding: 0;
    overflow-x: hidden;
    overflow-y: auto;
    width: 100vw;
    min-height: 100vh;
    /* Enhanced mobile scrolling */
    -webkit-overflow-scrolling: touch;
    touch-action: manipulation;
  }
}

#root {
  width: 100%;
  min-height: 100vh;
  position: relative;
  /* Enhanced mobile scrolling */
  -webkit-overflow-scrolling: touch;
  overflow-y: auto;
}

canvas {
  width: 100% !important;
  height: 100% !important;
  touch-action: none;
}

/* Animation for live updates */
.animate-fade-in {
  animation: fadeIn 0.5s ease-in-out;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
```

4. **Click** "Commit new file"

**Start with Step 1** - recreate the `client/index.html` file first.