# GitHub Copy & Paste Guide

## **Step 1: Create Repository**
1. **Go** to github.com
2. **Click** "New repository"
3. **Name** it: `cognitive-training-app`
4. **Click** "Create repository"

## **Step 2: Upload package.json**
1. **Click** "Create new file" button
2. **Type** `package.json` in the file name box
3. **Click** in the large text area below
4. **Copy** this content and **paste** it in the text area:

```json
{
  "name": "cognitive-training-app",
  "version": "1.0.0",
  "type": "module",
  "license": "MIT",
  "scripts": {
    "dev": "tsx server/index.ts",
    "build": "vite build && esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist",
    "start": "NODE_ENV=production node dist/index.js"
  },
  "dependencies": {
    "@capacitor/android": "^7.4.2",
    "@capacitor/cli": "^7.4.2",
    "@capacitor/core": "^7.4.2",
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "express": "^4.21.2",
    "vite": "^5.4.14"
  }
}
```

5. **Click** "Commit new file" button

## **Step 3: Upload capacitor.config.ts**
1. **Click** "Create new file" button
2. **Type** `capacitor.config.ts` in the file name box
3. **Click** in the large text area below
4. **Copy** this content and **paste** it in the text area:

```typescript
import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.cognitive.training',
  appName: 'Cognitive Training App',
  webDir: 'dist/public',
  server: {
    androidScheme: 'https'
  }
};

export default config;
```

5. **Click** "Commit new file" button

## **Where to Copy & Paste:**
- **File name box**: Top small box where you type the file name
- **Text area**: Large box below where you paste the content
- **Commit button**: Green button at bottom to save the file

Start with creating the repository, then upload these two files!