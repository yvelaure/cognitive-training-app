# Manual GitHub Workflow Setup

## **Add the Workflow File Manually:**

### **Step 1: Create the Workflow File**
1. **In your repository** on GitHub.com
2. **Click** "Add file" → "Create new file"
3. **Type** filename: `.github/workflows/build-android.yml`
4. **Copy** the workflow content below
5. **Paste** it into the file editor
6. **Click** "Commit new file"

### **Step 2: Workflow Content (Copy This):**
```yaml
name: Build Android APK

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v4
    
    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: '20'
        cache: 'npm'
        
    - name: Setup Java
      uses: actions/setup-java@v4
      with:
        distribution: 'temurin'
        java-version: '17'
        
    - name: Install dependencies
      run: npm ci
      
    - name: Build web app
      run: npm run build
      
    - name: Sync Capacitor
      run: npx cap sync android
      
    - name: Make gradlew executable
      run: chmod +x android/gradlew
      
    - name: Build APK
      run: cd android && ./gradlew assembleRelease
      
    - name: Upload APK
      uses: actions/upload-artifact@v4
      with:
        name: brain-games-hub-apk
        path: android/app/build/outputs/apk/release/app-release.apk
```

### **Step 3: After Creating the File**
1. **Wait** 1-2 minutes
2. **Refresh** the Actions tab
3. **You should see** "Build Android APK" workflow
4. **Click** "Run workflow" to start building

### **Step 4: Build Process**
- Build takes 5-10 minutes
- Download APK from "Artifacts" section when complete
- Professional APK with all 13+ games ready for Google Play Store

This manual method ensures the workflow is properly added to your repository.