# Privacy Policy - Brain Games Hub

**Effective Date**: January 16, 2025  
**Last Updated**: January 16, 2025

## Overview

Brain Games Hub ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, and protect your information when you use our mobile application and web service.

## Information We Collect

### Automatically Collected Information
- **Device Information**: Device type, operating system, browser type
- **Usage Data**: Game scores, play time, app interactions
- **Technical Data**: IP address, device identifiers, crash logs

### Information You Provide
- **Player Name**: Username for leaderboards and social features
- **Avatar Customization**: Selected avatar items and preferences
- **Game Progress**: Scores, achievements, and level progression
- **Payment Information**: Processed securely through third-party providers

## How We Use Your Information

### Primary Uses
- **Game Functionality**: Provide core gaming experience
- **Progress Tracking**: Save your scores and achievements
- **Leaderboards**: Display rankings and competition features
- **Personalization**: Customize difficulty and recommendations
- **Technical Support**: Troubleshoot issues and improve performance

### Secondary Uses
- **Analytics**: Understand user behavior and improve features
- **Marketing**: Send relevant updates and promotional content (opt-in only)
- **Security**: Detect fraud and protect against abuse

## Data Storage and Security

### Local Storage
- Game progress and preferences stored locally on your device
- Avatar customization and settings cached locally
- Offline functionality maintained through local storage

### Cloud Storage
- Leaderboard data stored securely on our servers
- Achievement data synchronized across devices
- Payment records maintained by certified payment processors

### Security Measures
- Industry-standard encryption for data transmission
- Secure servers with regular security updates
- Limited access to personal information
- Regular security audits and monitoring

## Third-Party Services

### Payment Processors
- **Stripe**: Credit card processing (stripe.com/privacy)
- **PayPal**: Digital payments (paypal.com/privacy)
- **Razorpay**: Regional payment processing (razorpay.com/privacy)
- **Square**: Payment processing (squareup.com/privacy)

### Analytics Services
- **Device Analytics**: Basic usage statistics (anonymous)
- **Performance Monitoring**: Crash reporting and performance metrics
- **User Behavior**: Aggregated and anonymized usage patterns

### Social Features
- **Leaderboards**: Global rankings and competition data
- **Social Sharing**: Optional sharing of achievements
- **Multiplayer**: Real-time game sessions with other players

## Your Rights and Choices

### Data Access
- View your saved game data and progress
- Download your personal information
- Request data correction or updates

### Data Control
- Delete your account and associated data
- Opt-out of marketing communications
- Disable social features and leaderboards
- Clear local storage and reset progress

### Privacy Settings
- Control avatar and profile visibility
- Manage social feature participation
- Adjust data sharing preferences
- Configure notification settings

## Children's Privacy

Brain Games Hub is designed for users 13 years and older. We do not knowingly collect personal information from children under 13. If you believe we have collected information from a child under 13, please contact us immediately.

## Data Retention

### Game Data
- Progress and scores: Retained until account deletion
- Leaderboard entries: Retained for ranking purposes
- Achievement data: Permanently stored unless deleted by user

### Technical Data
- Usage analytics: Aggregated and anonymized after 90 days
- Crash logs: Deleted after 30 days
- Device information: Deleted after 60 days of inactivity

## International Data Transfers

Your information may be transferred to and processed in countries other than your own. We ensure appropriate safeguards are in place to protect your data according to applicable privacy laws.

## Updates to This Policy

We may update this Privacy Policy periodically. We will notify you of significant changes through:
- In-app notifications
- Email notifications (if provided)
- Updated policy posted on our website

## Contact Information

If you have questions about this Privacy Policy or your data:

**Email**: privacy@braingameshubapp.com  
**Business Email**: contact@braingameshubapp.com  
**Website**: braingameshubapp.com  
**Response Time**: Within 48 hours

## Legal Compliance

This Privacy Policy complies with:
- General Data Protection Regulation (GDPR)
- California Consumer Privacy Act (CCPA)
- Children's Online Privacy Protection Act (COPPA)
- Apple App Store Privacy Guidelines
- Google Play Store Privacy Requirements

## Data Processing Lawful Basis

We process your data based on:
- **Performance of Contract**: Providing game services
- **Legitimate Interest**: Improving user experience and security
- **Consent**: Marketing communications and optional features
- **Legal Obligation**: Compliance with applicable laws

## Your California Privacy Rights

California residents have additional rights under CCPA:
- Right to know what personal information is collected
- Right to delete personal information
- Right to opt-out of sale of personal information
- Right to non-discrimination for exercising privacy rights

## Contact for Data Requests

For data access, deletion, or correction requests:
- Email: privacy@braingameshubapp.com
- Include: Full name, email address, and specific request
- Response time: Within 30 days

---

**Brain Games Hub Development Team**  
**Last Updated**: January 16, 2025  
**Version**: 1.0