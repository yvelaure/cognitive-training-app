# GitHub Desktop - Finding the Commit Button

## **Common Issues and Solutions:**

### **Issue 1: Button Not Visible**
- **Scroll down** in GitHub Desktop
- **Resize** the window to make it taller
- **Look** at the very bottom of the window

### **Issue 2: Button is Grayed Out**
- **Make sure** you typed a commit message
- **Check** that files are selected (checkmarked)
- **Try** clicking on the file again

### **Issue 3: Different Button Names**
The button might say:
- "Commit to main"
- "Commit to master"
- "Create commit"
- Just "Commit"

### **Alternative Method:**
1. **Press** Ctrl+Enter (Windows) or Cmd+Enter (Mac)
2. This is the keyboard shortcut for commit

### **What to Look For:**
- **Blue button** at the bottom left
- **Below** the commit message box
- **Might be partially hidden** - scroll down

### **If Still Can't Find It:**
1. **Close** GitHub Desktop completely
2. **Reopen** GitHub Desktop
3. **Click** on the workflow file again
4. **Try** typing the commit message again

The commit button should appear once you have:
- Selected a file with changes
- Typed a commit message
- The button area is visible (not scrolled off screen)