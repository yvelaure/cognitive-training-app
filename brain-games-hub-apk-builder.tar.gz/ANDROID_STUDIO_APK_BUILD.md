# Android Studio - Professional APK Build

## **Method 2: Android Studio (Professional)**

### **Step 1: Install Android Studio**
1. **Download** from developer.android.com/studio
2. **Install** with default settings
3. **Accept** Android SDK licenses
4. **Wait** for initial setup to complete

### **Step 2: Prepare Your Project**
1. **Download** your complete project from Replit
2. **Extract** to a folder on your computer
3. **Open** Android Studio
4. **Select** "Open an existing Android Studio project"
5. **Navigate** to your project's `android/` folder
6. **Click** "OK"

### **Step 3: Build Signed APK**
1. **Build** menu → **Generate Signed Bundle/APK**
2. **Select** "APK" option
3. **Click** "Next"
4. **Create** new keystore:
   - **Keystore path**: Choose location to save
   - **Password**: Create strong password
   - **Key alias**: "release-key"
   - **Key password**: Same as keystore password
   - **Validity**: 25 years
   - **Certificate info**: Fill your details
5. **Click** "Next"
6. **Select** "release" build variant
7. **Check** both signature versions
8. **Click** "Finish"

### **Step 4: Download APK**
1. **Wait** for build to complete (5-10 minutes)
2. **APK** saved to `android/app/release/`
3. **File** named `app-release.apk`
4. **Copy** to your device for testing

### **What You Get:**
- Professional signed APK
- Google Play Store ready
- All 13+ brain games included
- Native mobile features
- Optimized performance

This method gives you a professional APK that's ready for Google Play Store submission!